#pragma once

#include <QMainWindow>
#include <QTimer>
#include <QResizeEvent>
#include <QPushButton>

#include "paintscene.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private:
    Ui::MainWindow *ui;
    PaintScene *scene;
    QTimer *timer;

private:
    void resizeEvent(QResizeEvent * event);

private slots:
    void slotTimer();
    void on_btn_rhombus_clicked();
    void on_btn_rectangle_clicked();
    void on_btn_triangle_clicked();
    void on_btn_circle_clicked();
    void on_btn_square_clicked();
    void on_btn_pentagram_clicked();
    void on_btn_hexagon_clicked();
    void on_btn_hexagram_clicked();
    void on_btn_octogram_clicked();
    void on_btn_other_figure_clicked();
    void on_btn_painting_clicked();

    void on_spinBox_degree_valueChanged(int x);
    void on_spinBox_right_left_valueChanged(int x);
    void on_spinBox_up_down_valueChanged(int x);
    void on_btn_scale_valueChanged(int x);
};

