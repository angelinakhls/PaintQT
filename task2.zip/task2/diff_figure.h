#pragma once

#include <QObject>
#include <QGraphicsItem>
#include "figure.h"


class diff_figure : public Figure
{
    Q_OBJECT

public:
    explicit diff_figure(QPointF point, QObject *parent = 0);
    double Area();
    double Perimeter();

private:
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
};
