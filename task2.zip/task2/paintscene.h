#pragma once

#include <QGraphicsScene>
#include <QGraphicsSceneMouseEvent>
#include <qgraphicsitem.h>
#include "figure.h"

class PaintScene : public QGraphicsScene
{
    Q_OBJECT
    Q_PROPERTY(int typeFigure
                   READ typeFigure WRITE setTypeFigure
                       NOTIFY typeFigureChanged)

public:
    explicit PaintScene(QObject *parent = 0);

    void scalePolygon(float scaleFactor);
    int typeFigure() const;
    void setTypeFigure(const int type);
    void setRotation(const int angle);
    void setScale(int mashtab);
    void setX(int x);
    void setY(int y);
    QString ChangeLabel();

    enum FigureTypes {
        RectangleType,
        RombType,
        TriangleType,
        CircleType,
        SquareType,
        Star5Type,
        Star6Type,
        Star8Type,
        HexagonType,
        diff_figureType,
        PainttType
    };

signals:
    void typeFigureChanged();

private:
    Figure *tempFigure;
    int posX;
    int posY;
    int m_typeFigure;

private:
    void mousePressEvent(QGraphicsSceneMouseEvent * event);
    void mouseMoveEvent(QGraphicsSceneMouseEvent *event);

};
