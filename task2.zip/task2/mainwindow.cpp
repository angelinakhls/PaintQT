#include "mainwindow.h"
#include "paintscene.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);//создание всех виджетов определенных в файле .ui

    scene = new PaintScene();   // Инициализируем графическую сцену
    ui->graphicsView->setScene(scene);
    ui->graphicsView->setRenderHint(QPainter::Antialiasing);
    ui->graphicsView->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    ui->graphicsView->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    ui->graphicsView->setViewportUpdateMode(QGraphicsView::FullViewportUpdate);

    timer = new QTimer();
    connect(timer, &QTimer::timeout, this, &MainWindow::slotTimer);
    timer->start(1000);

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::slotTimer()
{
    scene->setSceneRect(0,0, ui->graphicsView->width() - 20, ui->graphicsView->height() - 20);
    ui->labe_5->setText(scene->ChangeLabel());
}

void MainWindow::resizeEvent(QResizeEvent *event)
{
    QMainWindow::resizeEvent(event);

    QSize newSize = event->size();//текущий размер окна

    ui->centralwidget->resize(newSize);
    ui->graphicsView->resize(newSize.width() * 2, newSize.height() * 2 );
    update();
}

void MainWindow::on_btn_rhombus_clicked()
{
    scene->setTypeFigure(PaintScene::RombType);
}

void MainWindow::on_btn_rectangle_clicked()
{
    scene->setTypeFigure(PaintScene::RectangleType);
}

void MainWindow::on_btn_triangle_clicked()
{
    scene->setTypeFigure(PaintScene::TriangleType);
}

void MainWindow::on_btn_circle_clicked()
{
    scene->setTypeFigure(PaintScene::CircleType);
}

void MainWindow::on_btn_square_clicked()
{
    scene->setTypeFigure(PaintScene::SquareType);
}

void MainWindow::on_btn_pentagram_clicked()
{
    scene->setTypeFigure(PaintScene::Star5Type);
}

void MainWindow::on_btn_hexagon_clicked()
{
    scene->setTypeFigure(PaintScene::HexagonType);
}

void MainWindow::on_btn_hexagram_clicked()
{
    scene->setTypeFigure(PaintScene::Star6Type);
}

void MainWindow::on_btn_octogram_clicked()
{
    scene->setTypeFigure(PaintScene::Star8Type);
}

void MainWindow::on_btn_other_figure_clicked()
{
    scene->setTypeFigure(PaintScene::diff_figureType);
}

void MainWindow::on_btn_painting_clicked()
{
    scene->setTypeFigure(PaintScene::PainttType);
}

void MainWindow::on_spinBox_degree_valueChanged(int x) {
    scene->setRotation(x);
}

void MainWindow::on_btn_scale_valueChanged(int x) {
    scene->setScale(x);
}

void MainWindow::on_spinBox_right_left_valueChanged(int x) {
    scene->setX(x);
}

void MainWindow::on_spinBox_up_down_valueChanged(int y) {
    scene->setY(y);
}


