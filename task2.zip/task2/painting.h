#pragma once

#include <QObject>
#include <QGraphicsItem>
#include "figure.h"

class Paintt : public Figure
{
    Q_OBJECT

public:
    explicit Paintt(QPointF point, QObject *parent = 0);


private:
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
};
