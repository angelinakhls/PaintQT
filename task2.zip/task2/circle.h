#pragma once

#include <QObject>
#include <QGraphicsItem>

#include "figure.h"

class Circle : public Figure
{
    Q_OBJECT

public:
    explicit Circle(QPointF point, QObject *parent = 0);
    double Ploshad();
    double Perimeter();

private:
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);
};
