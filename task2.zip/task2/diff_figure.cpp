#include "diff_figure.h"
#include <QPainter>
#include <cmath>


diff_figure::diff_figure(QPointF point, QObject *parent) :
    Figure(point,parent)
{
    Q_UNUSED(point)
}

void diff_figure::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    painter->setPen(QPen(Qt::black, 5));

    QPolygonF polygon;


    polygon << QPointF(startPoint().x(), startPoint().y())
            << QPointF(endPoint().x(), endPoint().y())
            << QPointF(endPoint().x() + 90, endPoint().y() + 90)
            << QPointF(startPoint().x() + 90, startPoint().y() + 90);

    painter->setBrush(Qt::blue);


    painter->drawPolygon(polygon);

    Q_UNUSED(option)
    Q_UNUSED(widget)

}


double diff_figure::Area(){
    return qAbs((startPoint().x() - endPoint().x()) * (startPoint().y() - endPoint().y()));
}

double diff_figure::Perimeter(){
    return 2 * (qSqrt(qPow(endPoint().x() - startPoint().x(), 2) + qPow(endPoint().y() - startPoint().y(), 2)) + qSqrt(qPow((endPoint().y() + 90) - endPoint().x(), 2) + qPow((endPoint().y() + 90) - endPoint().y(), 2)));
}
